<?php

namespace FtpPhp;

class FtpException extends Exception
{
}
